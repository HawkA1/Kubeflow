import sys
from Crypto.Util.number import *


flag=b"CSCS{Sm4lllll_eeeeeeeee_m4444k3eeee_iTTTTT_eeeeeeee4syyyyy}"
def encrypt():
    p=getPrime(1024)
    q=getPrime(1024)
    e=5
    n=p*q
    m=bytes_to_long(flag)
    c=pow(m,e,n)
    print("C =",c)
    print("\nN =",n)
    exit()

print("We implemented a really cool RSA ENCRYPTION generator. Check it out :)\n\n")
sys.stdout.flush()

print(encrypt())


