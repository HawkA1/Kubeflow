#! /bin/sh

cd /ctf
/usr/bin/python3 task.py
