from Crypto.Util.number import *
from Crypto.Random import *


secret=b'REDACTED'

p, q, s = [getPrime(512) for _ in range(3)]

n = p * q * s
e = 131074

m = bytes_to_long(secret)

pp = pow(p, e, n)
qq = pow(q, e, n)
c = pow(m, e, n)
hint1 = (pp - qq) % n
hint2 = pow(p - q, e, n)

print("e =", e)
print("n =", n)
print("hint1 =", hint1)
print("hint2 =", hint2)
print("c =", c)
