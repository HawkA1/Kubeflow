from Crypto.Util.number import *
from helper import *

def mapping(str1):
    for i in str1:
        if i not in "AbEglOSBTZ":
            print (i)
    str1 = str1.replace("O", '0')
    str1 = str1.replace("l", '1')
    str1 = str1.replace("Z", '2')
    str1 = str1.replace("E", '3')
    str1 = str1.replace("A", '4')
    str1 = str1.replace("S", '5')
    str1 = str1.replace("b", '6')
    str1 = str1.replace("T", '7')
    str1 = str1.replace("B", '8')
    str1 = str1.replace("g", '9')
    return str1


n = "lOgbTbgElTTbTSEEgAlAlEgASbASlATZOTEAZEbTgbSBAOZZBAZBZOSOTblEgASgTBEOAOgBgZOSZgAlZAlSblgTOBBSlElAAZEbTlABEZZSSOOElTlgSBEEAESTBglTAAglAlTBTlBbAZbOETSObbZTBBBSSTAZEZbSEZSbAZSAEAZgbllETTEgTEBTASAZTEEEZZbOOEbSlSbZEEgbSZESZgZZBllAbgEBbSZEOEETATSlSZSAZblOZTEZSEOTllAEOATEAbbgOEbSbAZBBAblBAEBTZBZSZBgSOOgSgbTSbTBBSEBl"

e = "AgAAbbTBbOOOSlETgZZBTbOgObZBbOEllSSSOgTAZZEgBEZbSgTOSTElSSgZAggBBZlOSTBSEgZllBlESAEblZAZSggOSOTBEllbOAOTlbSZSgOAbggllgAgESZbZZOOSbSgSEBAZSbTlABTBbOSEOAOASOlgBglgTSEBEAEgTETBlBBgEZSZASggBAOOZTOgEZgOZlTblZZBSZlAlOSTglgggbTESESSSbSSBAABSZEAABEEbElAAOlAlAbAABTgBZTlZTObAgZgBTBEBEZETAEZBgSlTOAAZlTbZllgAbZBbblTZOS"


c = "EgOSBZZggEObTgTZBOTZSOAAbgEggbABTObbbEBZbZbgBOgSOTgTOOTObAZSBAbBEOATbBbZTlbOTlTEgASBAEEBZOlEgglASSlZbgTllBSTglAlBOOETABBSSgglbBBObASBOSZABOgZZBgbblOlSBlTEBgTOggZOOlSOSSZlZTbEbATTgOggZlBZZASggbblABSOTBgTTBABbEElSbOZOTOABAOTZbEZbZSTTOlBlZSgbbbbbEAAlAbgAbBgOZZOZlgTEEZlBBAZEAZllbZBbOBbBZBlEBElBTOTASEZTbBgBlBABl"
def egcd(a, b):
    if a == 0: return (b, 0, 1)
    g, x, y = egcd(b % a, a)
    return (g, y - (b // a) * x, x)

def mod_inv(a, m):
    g, x, _ = egcd(a, m)
    return (x + m) % m

def isqrt(n):
    x = n
    y = (x + 1) // 2
    while y < x:
        x = y
        y = (x + n // x) // 2
    return x
  
def crack_rsa(e, n):
    frac = rational_to_contfrac(e, n)
    convergents = convergents_from_contfrac(frac)
    
    for (k, d) in convergents:
        if k != 0 and (e * d - 1) % k == 0:
            phi = (e * d - 1) // k
            s = n - phi + 1
            # check if x*x - s*x + n = 0 has integer roots
            D = s * s - 4 * n
            if D >= 0:
                sq = isqrt(D)
                if sq * sq == D and (s + sq) % 2 == 0: return d


n = int(mapping(n))
e = int(mapping(e))
c = int(mapping(c))

d = crack_rsa(e, n)
m = pow(c, d, n)
print(long_to_bytes(m))

